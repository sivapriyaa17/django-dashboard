from django.urls import path
from . import views
app_name = 'blog'
urlpatterns=[
    path('create/',views.create,name='create'),
    path('my-blogs/',views.blogs,name='my-blogs'),
    path('blogs/',views.public,name='public'),
]
