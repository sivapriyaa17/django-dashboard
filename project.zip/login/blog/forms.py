from django import forms
from .models import blogpost

class BlogPostForm(forms.ModelForm):
    class Meta:
        model = blogpost
        fields = ['title', 'image', 'category', 'summary', 'content', 'draft']
