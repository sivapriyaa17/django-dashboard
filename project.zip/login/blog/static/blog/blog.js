document.addEventListener('DOMContentLoaded', function () {
    const blogForm = document.getElementById('blogForm');
    if (blogForm) {
      blogForm.addEventListener('submit', async function (e) {
        e.preventDefault();
        const formData = new FormData(blogForm);
  
        const response = await fetch(blogForm.action, {
          method: 'POST',
          body: formData
        });
  
        if (response.redirected) {
          window.location.href = response.url;
        } else {
          alert("Blog submission failed.");
        }
      });
    }
  
    // Truncate summaries to 15 words
    const summaries = document.querySelectorAll('.summary');
    summaries.forEach(el => {
      const words = el.textContent.trim().split(/\s+/);
      if (words.length > 15) {
        el.textContent = words.slice(0, 15).join(' ') + '...';
      }
    });
  });
  