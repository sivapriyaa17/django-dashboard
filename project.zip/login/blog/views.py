from django.shortcuts import render,redirect
from .models import Category,blogpost
from .forms import BlogPostForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import Group
@login_required
def create(request):
    if request.user.type != 'doctor':
        return redirect('blog:blogs') 
    if request.method == 'POST':
        form = BlogPostForm(request.POST, request.FILES)
        if form.is_valid():
            blog_post = form.save(commit=False)
            blog_post.author = request.user  # Set the logged-in user as author
            blog_post.save()
            return redirect('blog:my-blogs')  # Redirect to the doctor’s blog list page
    else:
        form = BlogPostForm()
    return render(request, 'blog/create.html', {'form': form})
'''def create(request):
    if request.method=="POST":
        blog=blogpost(
            title=request.POST['title'],
            image=request.FILES['image'],
            category=Category.objects.get(id=request.POST['category']),
            summary=request.POST['summary'],
            content=request.POST['content'],
            draft='draft' in request.POST,
            author=request.user
                )
        blog.save()
        return redirect('blog:public')
    categories=Category.objects.all()
    return render(request,'blog/create.html',{'categories':categories})'''
@login_required
def blogs(request):
    blog=blogpost.objects.filter(author=request.user)
    return render(request,'blog/my-blogs.html',{'blog':blog})
@login_required
def public(request):
    categories = blogpost.CATEGORY_CHOICES
    c_blogs = {}
    for category in categories:
        category_key=category[0]
        posts=blogpost.objects.filter(category=category_key,draft=False)
        c_blogs[category_key] = posts
    return render(request, 'blog/public.html', {'c_blogs': c_blogs})

# Create your views here.
